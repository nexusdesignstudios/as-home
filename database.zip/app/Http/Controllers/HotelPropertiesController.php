<?php

namespace App\Http\Controllers;

use App\Models\Property;
use App\Models\HotelRoom;
use App\Models\HotelRoomType;
use App\Services\BootstrapTableService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HotelPropertiesController extends Controller
{
    /**
     * Display a listing of hotel properties.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!has_permissions('read', 'hotel_properties')) {
            return redirect()->back()->with('error', PERMISSION_ERROR_MSG);
        }

        return view('hotel_properties.index');
    }

    /**
     * Get hotel properties for bootstrap table.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getHotelPropertiesList(Request $request)
    {
        $offset = $request->offset ?? 0;
        $limit = $request->limit ?? 10;
        $sort = $request->sort ?? 'id';
        $order = $request->order ?? 'DESC';
        $search = $request->search ?? '';

        // Query only hotel properties (classification = 5)
        $sql = Property::classification(5)->orderBy($sort, $order);

        if (!empty($search)) {
            $sql = $sql->where(function ($query) use ($search) {
                $query->where('title', 'LIKE', "%$search%")
                    ->orWhere('address', 'LIKE', "%$search%")
                    ->orWhere('client_address', 'LIKE', "%$search%");
            });
        }

        $total = $sql->count();
        $sql = $sql->skip($offset)->take($limit);
        $res = $sql->get();

        $bulkData = [];
        $bulkData['total'] = $total;
        $rows = [];

        foreach ($res as $row) {
            $tempRow = [];
            $tempRow['id'] = $row->id;
            $tempRow['title'] = $row->title;
            $tempRow['address'] = $row->address;
            $tempRow['refund_policy'] = $row->refund_policy ?? 'N/A';
            $tempRow['room_count'] = $row->hotelRooms()->count();
            $tempRow['status'] = $row->status;
            $tempRow['created_at'] = $row->created_at;

            $operate = '';

            // View property details
            if (has_permissions('read', 'property')) {
                $operate .= '<a href="' . route('property.show', $row->id) . '" class="btn btn-sm btn-primary" title="View"><i class="bi bi-eye"></i></a>&nbsp;&nbsp;';
            }

            // Edit property
            if (has_permissions('update', 'property')) {
                $operate .= '<a href="' . route('property.edit', $row->id) . '" class="btn btn-sm btn-success" title="Edit"><i class="bi bi-pencil-square"></i></a>&nbsp;&nbsp;';
            }

            // Delete property
            if (has_permissions('delete', 'property')) {
                $operate .= '<a href="javascript:void(0)" class="btn btn-sm btn-danger delete-data" data-id="' . $row->id . '" data-url="' . route('property.destroy', $row->id) . '" title="Delete"><i class="bi bi-trash"></i></a>';
            }

            $tempRow['operate'] = $operate;
            $rows[] = $tempRow;
        }

        $bulkData['rows'] = $rows;
        return response()->json($bulkData);
    }
}
